# NST Package Manager

A custom packaging system for Debian-based systems that creates and installs `.nst` package files.

## Project Structure

- `nst_create`: Script to create new NST packages
- `nst_install`: Script to install NST packages
- `templates/`: Directory containing package templates
- `src/`: Source code for the package manager
- `examples/`: Example NST packages
- `docs/`: Documentation

## Creating a Package

1. Create a package directory structure:
   ```
   myapp_1.0.0/
   ├── files/           # Files to be installed
   ├── meta/           
   │   ├── depends     # Package dependencies
   │   ├── links       # Installation paths mapping
   │   └── postinst    # Post-installation script
   └── icons/          # Application icons
   ```

2. Run the package creator:
   ```bash
   ./nst_create myapp_1.0.0/
   ```

## Installing a Package

```bash
sudo ./nst_install myapp_1.0.0.nst
```

## File Format Specification

### meta/depends
List of package dependencies, one per line:
```
package1
package2>=1.0.0
```

### meta/links
Mapping of source files to installation paths:
```
files/myapp=/usr/local/bin/myapp
files/icon.png=/usr/share/icons/hicolor/128x128/apps/myapp.png
```

### meta/postinst
Bash script to run after installation:
```bash
#!/bin/bash
# Post-installation script
echo "Configuring myapp..."
update-desktop-database
```
